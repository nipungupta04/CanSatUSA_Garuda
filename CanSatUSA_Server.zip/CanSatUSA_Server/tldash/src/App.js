import logo from './logo.svg';
import Dashboard from './pages/Dashboard';
// import './App.css';

function App() {
  return (
    <Dashboard/>
  );
}

export default App;
