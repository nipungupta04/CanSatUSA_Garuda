import React from "react";
import RealChart from "./RealChart";

const Minigraph = (props) => {
    return (
        <div className="bg-white flex font-mulish rounded-xl border border-stroke drop-shadow-sm p-4 flex-col relative h-48">
            <h4 className="font-semibold text-base z-10 relative">
                {props.subtype}
            </h4>
            <div className="flex-row flex items-end z-10 relative">
                <h3 className="font-normal text-3xl pr-1">{props.alt}</h3>
                <h4 className="font-bold text-base text-light-gray">
                    {props.unit}
                </h4>
            </div>
            <div className="absolute bottom-0 inset-x-0 pb-4 pr-4 pl-4 pt-0">
                <RealChart color={props.color} subtype = {props.subtype}/>
            </div>
        </div>
    );
}

export default Minigraph;
 